from bs4 import BeautifulSoup
import requests
import csv

sauce = requests.get('https://phxlabs.ca/#our-story').text

csv_file = open('details.csv','w')
csv_writer = csv.writer(csv_file)
csv_writer.writerow(['Name','IGN'])

#with open('Phoenix_Labs.html') as html_file:
soup = BeautifulSoup(sauce,'lxml')

for teammem in soup.find_all('div',class_="team-member"):
	name = teammem.h4.text
	ign = teammem.h5.text
	print(name)
	print(ign)
	print(" ")
	csv_writer.writerow([name,ign])



